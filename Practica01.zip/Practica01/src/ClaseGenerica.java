import java.util.ArrayList;
import java.util.List;

public class ClaseGenerica<T> {
    private List<T> lista;

    public ClaseGenerica() {
        this.lista = new ArrayList<>();
    }

    public void agregar(T objeto) {
        lista.add(objeto);
    }

    public List<T> obtenerTodos() {
        return lista;
    }
    
    public void eliminar(T objeto) {
        lista.remove(objeto);
    }
}