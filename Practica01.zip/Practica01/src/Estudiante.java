public class Estudiante {
    private String nombre;
    private String cedula;
    private String carrera;
    private String nivel;

    public Estudiante(String nombre, String cedula, String carrera, String nivel) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.carrera = carrera;
        this.nivel = nivel;
    }

    // Getters y toString para visualizar datos
    @Override
    public String toString() {
        return "Estudiante [Cédula=" + cedula + ", Nombre=" + nombre + 
               ", Carrera=" + carrera + ", Nivel=" + nivel + "]";
    }
    
    public String getCedula() { return cedula; }
}