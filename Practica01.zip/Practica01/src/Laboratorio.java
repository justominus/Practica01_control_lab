public class Laboratorio {
    
    public enum TipoLaboratorio {
        IHM, 
        COMPUTACION_AVANZADA, 
        NETWORKING_1, 
        NETWORKING_2, 
        NETWORKING_3
    }

    private TipoLaboratorio nombre;

    public Laboratorio(TipoLaboratorio nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Laboratorio: " + nombre;
    }
}