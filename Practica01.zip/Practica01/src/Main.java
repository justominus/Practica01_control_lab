import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Lista general de estudiantes registrados
        ClaseGenerica<Estudiante> listaEstudiantes = new ClaseGenerica<>();
        // Cola de reservas (ArrayList con lógica FIFO)
        ClaseGenerica<String> colaReservas = new ClaseGenerica<>();
        
        int opcion = 0;

        do {
            System.out.println("\n--- SISTEMA LABSCHEDULER (UPS) ---");
            System.out.println("1. Agregar Estudiante");
            System.out.println("2. Ingresar Reserva (Encolar)");
            System.out.println("3. Cancelar Reserva (Desencolar el primero)");
            System.out.println("4. Ver Reservas");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.print("Nombre: "); String nom = sc.nextLine();
                    System.out.print("Cédula: "); String ced = sc.nextLine();
                    System.out.print("Carrera: "); String car = sc.nextLine();
                    System.out.print("Nivel: "); String niv = sc.nextLine();
                    listaEstudiantes.agregar(new Estudiante(nom, ced, car, niv));
                    System.out.println("Estudiante registrado con éxito.");
                    break;

                case 2:
                    System.out.println("Seleccione el Laboratorio:");
                    int i = 1;
                    for (Laboratorio.TipoLaboratorio lab : Laboratorio.TipoLaboratorio.values()) {
                        System.out.println(i++ + ". " + lab);
                    }
                    int sel = sc.nextInt();
                    sc.nextLine();
                    
                    if(sel > 0 && sel <= 5) {
                        System.out.print("Ingrese Cédula del estudiante: ");
                        String cReserva = sc.nextLine();
                        String labNombre = Laboratorio.TipoLaboratorio.values()[sel-1].toString();
                        // Se agrega al final de la lista (Cola)
                        colaReservas.agregar("Estudiante: " + cReserva + " | Lab: " + labNombre);
                        System.out.println("Reserva añadida a la cola de espera.");
                    } else {
                        System.out.println("Opción de laboratorio no válida.");
                    }
                    break;

                case 3:
                    // Lógica de COLA: El primero en llegar es el primero en salir (FIFO)
                    if (!colaReservas.obtenerTodos().isEmpty()) {
                        String eliminada = colaReservas.obtenerTodos().remove(0); // Elimina índice 0
                        System.out.println("Reserva procesada/cancelada: " + eliminada);
                    } else {
                        System.out.println("No hay reservas pendientes en la cola.");
                    }
                    break;

                case 4:
                    System.out.println("\n--- ESTADO ACTUAL DE LA COLA ---");
                    if (colaReservas.obtenerTodos().isEmpty()) {
                        System.out.println("La cola está vacía.");
                    } else {
                        for (int j = 0; j < colaReservas.obtenerTodos().size(); j++) {
                            System.out.println((j + 1) + ". " + colaReservas.obtenerTodos().get(j));
                        }
                    }
                    break;
            }
        } while (opcion != 5);
        
        System.out.println("Cerrando sistema de gestión...");
        sc.close();
    }
}